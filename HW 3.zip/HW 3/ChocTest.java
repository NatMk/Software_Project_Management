import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ChocTest {
	/*
	 * create output stream for the contents of the array
	 */
	
    private static vendingMachine obj;
    static private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    static private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

    @BeforeAll
    public static void init() {
        obj = new vendingMachine();
        System.setOut(new PrintStream(outContent)); /* After this all System.out.println() statements will come to outContent stream. */
        System.setErr(new PrintStream(errContent)); /* Turns on stdErr output capture */
    }

    @AfterAll
    public static void exit() {
        System.setOut(System.out); /* reassigns the "standard" output stream. */
        System.setErr(System.err); /* reassigns the "standard" error output stream. */
    }

    @Test
    public void test_choc() {
        assertEquals(obj.coin(0), 0); /*assertEquals checks if the two objects are equals or not */
        assertEquals("Coin is not accpted!!!\r\n", outContent.toString());
        outContent.reset(); /** adjusts the contents for the next comparison **/
        assertEquals(obj.getChoc(new StringBuffer()), 0);
        assertEquals("No enough money!!!\r\n", outContent.toString()); /** check if the string equals the string from the method on the right **/
        outContent.reset();
        assertEquals(obj.coin(25), 25);
        assertEquals(obj.getChoc(new StringBuffer()), 25);
        assertEquals("No enough money!!!\r\n", outContent.toString());
        outContent.reset();
        assertEquals(obj.coin(25), 50);
        assertEquals(obj.coin(100), 150);
        assertEquals(obj.getChoc(new StringBuffer()), 150);
        assertEquals("Sold out!\r\n", outContent.toString());
        outContent.reset();
        obj.addChoc("fg");
        assertEquals("fg is not accpted!!!\r\n", outContent.toString());
        outContent.reset();
        obj.addChoc("c1");
        assertEquals(obj.getChoc(new StringBuffer("c1")), 60);
    }
}
