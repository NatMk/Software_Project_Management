import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CoinTest {
	 /*
	 * create output stream for the contents of the array
	 */

    private static vendingMachine obj;
    static private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    static private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

    @BeforeAll
    public static void init() {
        obj = new vendingMachine();
        System.setOut(new PrintStream(outContent));/* After this all System.out.println() statements will come to outContent stream. */
        System.setErr(new PrintStream(errContent)); /* Turns on stdErr output capture */
    }

    @AfterAll
    public static void exit() {
        System.setOut(System.out); /* reassigns the "standard" output stream. */
        System.setErr(System.err); /* reassigns the "standard" error output stream. */
    }

    @Test
    public void test_coin() {
        assertEquals(obj.coin(0), 0); /*assertEquals checks if the two objects are equals or not */
        assertEquals("Coin is not accpted!!!\r\n", outContent.toString());
        outContent.reset();  /** adjusts the contents for the next comparison **/
        assertEquals(obj.coin(1), 1);
        assertEquals("Coin is not accpted!!!\r\n", outContent.toString()); /** check if the string equals the string from the method on the right **/
        outContent.reset();
        assertEquals(obj.coin(5), 5);
        assertEquals("Coin is not accpted!!!\r\n", outContent.toString());
        outContent.reset();
        assertEquals(obj.coin(20), 20);
        assertEquals("Coin is not accpted!!!\r\n", outContent.toString());
        outContent.reset();
        assertEquals(obj.coin(-1), -1);
        assertEquals("Coin is not accpted!!!\r\n", outContent.toString());
        outContent.reset();
        assertEquals(obj.coin(10), 10); /*assertEquals checks if the two objects are equals or not */
        assertEquals(obj.coin(25), 35);
        assertEquals(obj.coin(10), 45);
        assertEquals(obj.coin(100), 145);
        assertEquals(obj.coin(100), 100);
        assertEquals("No need more money!!!\r\n", outContent.toString());
        outContent.reset(); /** Done with the contents for comparison **/
    }
}
